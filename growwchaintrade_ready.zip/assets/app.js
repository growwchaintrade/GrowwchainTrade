// Interactions for GrowwChainTrade
document.getElementById('year').textContent = new Date().getFullYear();
// reveal on scroll
const obs = new IntersectionObserver((entries)=>{ entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('visible'); }); }, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el=>obs.observe(el));
// TradingView advanced chart loader
let current = 'BINANCE:BTCUSDT';
function loadChart(sym){ const container = document.getElementById('tv-chart'); container.innerHTML = ''; const s = document.createElement('script'); s.async=true; s.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js'; s.innerHTML = JSON.stringify({ autosize:true, symbol: sym, interval:'60', timezone:'Etc/UTC', theme:'dark', style:'1', locale:'en', hide_top_toolbar:false, allow_symbol_change:true, withdateranges:true }); container.appendChild(s); current = sym; }
loadChart(current);
document.querySelectorAll('.chip').forEach(b=>b.addEventListener('click', ()=>{ document.querySelectorAll('.chip').forEach(x=>x.classList.remove('active')); b.classList.add('active'); loadChart(b.dataset.symbol); }));
// Smooth internal links
document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click', e=>{ const id = a.getAttribute('href').slice(1); const el = document.getElementById(id); if(el){ e.preventDefault(); el.scrollIntoView({ behavior: 'smooth', block: 'start' }); } }));
// Ticker widget is injected in index via script tag in HTML
